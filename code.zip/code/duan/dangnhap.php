
<?php
$sever = 'localhost';
$user = 'root';
$pass = '';
$database = 'db_tranhsondau';

$conn = new mysqli($sever, $user, $pass, $database);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối cơ sở dữ liệu thất bại: " . $conn->connect_error);
}

session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Lấy thông tin từ form
    $ma = $_POST['ma']; // Lấy mã người dùng
    $matkhau = $_POST['matkhau'];

    // Kiểm tra dữ liệu nhập
    if (empty($ma) || empty($matkhau)) {
        echo "Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu.";
        exit();
    }

    // Truy vấn kiểm tra thông tin đăng nhập
    $sql = "SELECT * FROM nguoidung WHERE ma = ? AND matkhau = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $ma, $matkhau);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Lưu thông tin người dùng vào session
        $_SESSION['user'] = [
            'ma' => $user['ma'],
            'ten' => $user['ten'],
            'quyen' => $user['quyen']
        ];

        // Phân quyền và chuyển hướng
        if ($user['quyen'] == 'admin') {
            header('Location: quantri.php'); // Trang quản trị
        } elseif ($user['quyen'] == 'user') {
            header('Location: trangchu.php'); // Trang người dùng
        } else {
            header('Location: trangchu.php');
        }
    } else {
        header('Location: dangnhap.php');
    }
    // Kiểm tra nếu người dùng chưa đăng nhập
?>
   
<?php

}
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap 5 Website Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
  .fakeimg {
    height: 200px;
    background: #aaa;
  }

  #canhbao{
    color: red;
  }
  </style>
</head>
<body>

<div class="p-5 bg-primary text-white text-center">
  <h1>ĐĂNG NHẬP</h1>
  
</div>

<div class="container-fluid mt-5">

  <div class="row">
    <div class="col-sm-4">
      <h2>   </h2>
      
      <ul class="nav flex-column">
   
        <li class="nav-item">
          <a class="nav-link" href="#">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li><li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        
      
      
        
      </ul>
    </div>

<!--end header-->

    <div class="col-sm-8">
    <form method = "post"> 
            <input id="MA" type = "text" name = "ma" placeholder="Nhập mã">
            <input id="MATKHAU" type = "password" name = "matkhau" placeholder="Nhập mật khẩu">
            <input id="DK" type = "submit" name = "them" value = "Đăng Nhập"> 
     </form>
  </div>

<!--start footer-->
<?php
  include_once("footer.php");
?>
<style>
#MA{
    width: 200px;

}
#MATKHAU{
    right: 90%;
    margin-top: 20%;
}
</style>
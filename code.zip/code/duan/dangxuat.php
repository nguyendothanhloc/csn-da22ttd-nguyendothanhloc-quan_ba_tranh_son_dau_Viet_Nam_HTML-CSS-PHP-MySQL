<?php
session_start(); // Bắt đầu session

// Hủy toàn bộ session
session_unset(); // Xóa tất cả các biến session
session_destroy(); // Hủy session

// Chuyển hướng về trang đăng nhập hoặc trang chủ
header("Location: dangnhap.php"); 
exit(); // Dừng script
?>
<?php
session_start();

// Kiểm tra nếu người dùng chưa đăng nhập
if (!isset($_SESSION['user'])) {
    header("Location: dangnhap.php"); // Chuyển hướng về trang đăng nhập
    exit();
}

// Nội dung trang web cho người dùng đã đăng nhập
echo "Chào mừng " . $_SESSION['user']['ten'];
?>

<?php
$sever = 'localhost';
$user = 'root';
$pass = '';
$database = 'db_tranhsondau';

$conn = new mysqli($sever, $user, $pass, $database);
?>
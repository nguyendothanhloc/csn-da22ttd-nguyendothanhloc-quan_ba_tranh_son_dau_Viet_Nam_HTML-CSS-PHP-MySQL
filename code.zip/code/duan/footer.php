<div class="mt-5 p-4 bg-dark text-white text-center">
  <p>chào mừng đến với website</p>
</div>
</div>
</body>
</html>
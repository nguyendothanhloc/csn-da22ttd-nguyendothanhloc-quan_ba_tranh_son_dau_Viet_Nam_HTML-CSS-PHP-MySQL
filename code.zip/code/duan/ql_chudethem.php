<?php
$sever = 'localhost';
$user = 'root';
$pass = '';
$database = 'db_tranhsondau';
   
    $conn = new mysqli($sever, $user, $pass, $database);
    
    session_start();
    if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['them'])){
        $ma = $_POST['ma'];
        $ten = $_POST['ten'];
    $them = "INSERT INTO chude (ma, ten )VALUES(?,?) ";
        $n = $conn->prepare($them);
        $n->bind_param("is", $ma, $ten);
        $n->execute();
        $n->close();
        header('Location: ql_chude.php');
        exit();

    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap 5 Website Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
  .fakeimg {
    height: 200px;
    background: #aaa;
  }








  

#MA{
    position: absolute;
    width: 300px;
    height: 30px;
    top:40%;
    left: 37%;  
}



#TEN{
    position: absolute;
    width: 300px;
    height: 30px;
    top:45%;
    left: 37%;  
}


#DK{
    position: absolute;
    width: 300px;
    height: 30px;
    top:50%;
    left: 37%;
}

  </style>
</head>
<body>

<div class="p-5 bg-primary text-white text-center">
  <h1>TRANG QUẢN TRỊ</h1>
  
</div>

<div class="container-fluid mt-5">

  <div class="row">
    <div class="col-sm-4">
      <h2>Quản lý dữ liệu</h2>
      
      <ul class="nav flex-column">
      <li class="nav-item">
          <a class="nav-link" href="quantri.php">Trang chủ quản trị</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_nguoidung.php">Người dùng</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_chude.php">Chủ đề</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_tacgia.php">Tác giả</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_tacpham.php">Tác phẩm</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">Bình luận</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Đăng xuất</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        

      
        
      </ul>
    </div>

<!--end header-->

    <div class="col-sm-8">
    <form method = "post"> 
            <input id="MA" type = "text" name = "ma" placeholder="Nhập mã">
            <input id="TEN" type = "text" name = "ten" placeholder="Nhập tên">
            <input id="DK" type = "submit" name = "them" value = "Thêm">
     </form>
      
  </div>

<!--start footer-->
<?php
  include_once("footer.php");
?>

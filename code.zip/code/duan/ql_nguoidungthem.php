<?php
$sever = 'localhost';
$user = 'root';
$pass = '';
$database = 'db_tranhsondau';
    $conn = new mysqli($sever, $user, $pass, $database);
    
    session_start();
    if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['them'])){
        $ma = $_POST['ma'];
        $matkhau = $_POST['matkhau'];
        $ten = $_POST['ten'];
        $hoten = $_POST['hoten'];
        $diachi = $_POST['diachi'];
        $sodienthoai = $_POST['sodienthoai'];
        $quyen = $_POST['quyen'];
    $them = "INSERT INTO nguoidung (ma, matkhau, ten, hoten, diachi, sodienthoai, quyen )VALUES(?,?,?,?,?,?,?) ";
        $n = $conn->prepare($them);
        $n->bind_param("issssss", $ma, $matkhau, $ten, $hoten, $diachi, $sodienthoai, $quyen);
        $n->execute();
        $n->close();
        header('Location: quantri.php');
        exit();

    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap 5 Website Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
  .fakeimg {
    height: 200px;
    background: #aaa;
  }








#SDT{
    position: absolute;
    width: 300px;
    height: 30px;
    top:60%;
    left: 37%;  
}

#DC{
    position: absolute;
    width: 300px;
    height: 30px;
    top:53%;
    left: 37%;  
}
#MA{
    position: absolute;
    width: 300px;
    height: 30px;
    top:25%;
    left: 37%;  
}

#MATKHAU{
    position: absolute;
    width: 300px;
    height: 30px;
    top:32%;
    left: 37%;  
}
#TEN{
    position: absolute;
    width: 300px;
    height: 30px;
    top:39%;
    left: 37%;  
}

#HOTEN{
    position: absolute;
    width: 300px;
    height: 30px;
    top:46%;
    left: 37%;  
}
#DK{
    position: absolute;
    width: 300px;
    height: 30px;
    top:68%;
    left: 37%;
}

  </style>
</head>
<body>

<div class="p-5 bg-primary text-white text-center">
  <h1>TRANG QUẢN TRỊ</h1>
  
</div>

<div class="container-fluid mt-5">

  <div class="row">
    <div class="col-sm-4">
      <h2>Quản lý dữ liệu</h2>
      
      <ul class="nav flex-column">
      <li class="nav-item">
          <a class="nav-link" href="quantri.php">Trang chủ quản trị</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_nguoidung.php">Người dùng</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_chude.php">Chủ đề</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_tacgia.php">Tác giả</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_tacpham.php">Tác phẩm</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">Bình luận</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Đăng xuất</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>

      
        
      </ul>
    </div>

<!--end header-->

    <div class="col-sm-8">
    <form method = "post"> 
            <input id="MA" type = "text" name = "ma" placeholder="Nhập mã">
            <input id="MATKHAU" type = "password" name = "matkhau" placeholder="Nhập mật khẩu">
            <input id="TEN" type = "text" name = "ten" placeholder="Nhập tên">
            <input id="HOTEN" type = "text" name = "hoten" placeholder="Nhập họ tên">
            <input id="DC" type = "text" name = "diachi" placeholder="Nhập địa chỉ">
            <input id="SDT" type = "text" name = "sodienthoai" placeholder="Nhập số điện thoại">
            <input id="DK" type = "submit" name = "them" value = "Thêm">
     </form>
      
  </div>

<!--start footer-->
<?php
  include_once("footer.php");
?>

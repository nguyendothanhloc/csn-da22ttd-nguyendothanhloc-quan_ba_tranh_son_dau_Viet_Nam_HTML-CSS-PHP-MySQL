
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap 5 Website Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
  .fakeimg {
    height: 200px;
    background: #aaa;
  }



  </style>
</head>
<body>

<div class="p-5 bg-primary text-white text-center">
  <h1>TRANG QUẢN TRỊ</h1>
  
</div>

<div class="container-fluid mt-5">

  <div class="row">
    <div class="col-sm-4">
      <h2>Quản lý dữ liệu</h2>
      
      <ul class="nav flex-column">
      <li class="nav-item">
          <a class="nav-link" href="quantri.php">Trang chủ quản trị</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_nguoidung.php">Người dùng</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_chude.php">Chủ đề</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_tacgia.php">Tác giả</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_tacpham.php">Tác phẩm</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">Bình luận</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Đăng xuất</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        
      </ul>
    </div>

<!--end header-->

    <div class="col-sm-8">
    <form action = "ql_nguoidungxoa2.php" method = "post">
    <div class = "form-group">
        <label for = "ten">nhập mã người dùng muốn xóa</label>
        <input class = "form-control" type= "text" name = "ma" id = "ma">
    </div>
    <input class = "btn btn-primary mt-4" type="submit" name="xoa" value="xóa">

</form>
      
  </div>

<!--start footer-->
<?php
  include_once("footer.php");
?>

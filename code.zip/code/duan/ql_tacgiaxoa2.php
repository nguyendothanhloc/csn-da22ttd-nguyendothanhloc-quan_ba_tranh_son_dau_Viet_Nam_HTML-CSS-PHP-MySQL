<?php
$sever = 'localhost';
$user = 'root';
$pass = '';
$database = 'db_tranhsondau';

$conn = new mysqli($sever, $user, $pass, $database);


$ma = $_POST["ma"];
// sql to delete a record
$sql = "DELETE FROM tacgia WHERE ma='$ma'";

if ($conn->query($sql) === TRUE) {
  echo "Xóa thành công";
  header("Location:ql_nguoidung.php");
} else {
  echo "Lỗi:  " . $conn->error;
}

$conn->close();
?>
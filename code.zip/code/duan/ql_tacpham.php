

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap 5 Website Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
  .fakeimg {
    height: 200px;
    background: #aaa;
  }

#them{
    width: 200px;
    height: 100px;
    border: none;
    margin-left: 1%;
}
#xoa{
    width: 200px;
    height: 100px;
    border: none;
    margin-left: 3%;
}
#sua{
    width: 200px;
    height: 100px;
    border: none;
    margin-left: 5%;
    
}



  </style>
</head>
<body>

<div class="p-5 bg-primary text-white text-center">
  <h1>TRANG QUẢN TRỊ</h1>
  
</div>

<div class="container-fluid mt-5">

  <div class="row">
    <div class="col-sm-4">
      <h2>Quản lý dữ liệu</h2>
      
      <ul class="nav flex-column">
      <li class="nav-item">
          <a class="nav-link" href="quantri.php">Trang chủ quản trị</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_nguoidung.php">Người dùng</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_chude.php">Chủ đề</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_tacgia.php">Tác giả</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_tacpham.php">Tác phẩm</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">Bình luận</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Đăng xuất</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">   </a>
        </li>
      
      
        
      </ul>
    </div>

<!--end header-->

    <div class="col-sm-8">
   <div class="txs">
    <button id="them"><a href="ql_tacphamthem.php" style="text-decoration: none;">THÊM</a></button>
    <button id="them"><a href="ql_tacphamxoa.php" style="text-decoration: none;">XOÁ</a></button>
    
   </div>
      
  </div>

<!--start footer-->
<?php
  include_once("footer.php");
?>

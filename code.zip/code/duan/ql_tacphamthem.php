<?php
$sever = 'localhost';
$user = 'root';
$pass = '';
$database = 'db_tranhsondau';
   
    $conn = new mysqli($sever, $user, $pass, $database);
    
    session_start();
    if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['them'])){
        $ma = $_POST['ma'];
        $ten = $_POST['ten'];
        $machude = $_POST['machude'];
        $matacgia = $_POST['matacgia'];
        $hinhanh = $_POST['hinhanh'];
        $mota = $_POST['mota'];
        $namsangtac = $_POST['namsangtac'];
        $chatlieu = $_POST['chatlieu'];
        $kichthuoc = $_POST['kichthuoc'];
        $gia = $_POST['gia'];
        
    $them = "INSERT INTO tacpham (ma, ten, machude, matacgia, hinhanh, mota, namsangtac, chatlieu, kichthuoc, gia )VALUES(?,?,?,?,?,?,?,?,?,?) ";
        $n = $conn->prepare($them);
        $n->bind_param("isiississd", $ma, $ten, $machude,$matacgia, $hinhanh, $mota, $namsangtac, $chatlieu, $kichthuoc, $gia);
        $n->execute();
        $n->close();
        header('Location: ql_tacpham.php');
        exit();

    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap 5 Website Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
  .fakeimg {
    height: 200px;
    background: #aaa;
  }
#MA{
    position: absolute;
    width: 300px;
    height: 30px;
    top:25%;
    left: 37%;
}
#TEN{
    position: absolute;
    width: 300px;
    height: 30px;
    top:30%;
    left: 37%;
}
#MACHUDE{
    position: absolute;
    width: 300px;
    height: 30px;
    top:35%;
    left: 37%;
}
#MATACGIA{
    position: absolute;
    width: 300px;
    height: 30px;
    top:40%;
    left: 37%;
}
#HINHANH{
    position: absolute;
    width: 300px;
    height: 30px;
    top:45%;
    left: 37%;
}
#MOTA{
    position: absolute;
    width: 300px;
    height: 30px;
    top:50%;
    left: 37%;
}
#NAMSANGTAC{
    position: absolute;
    width: 300px;
    height: 30px;
    top:55%;
    left: 37%;
}
#CHATLIEU{
    position: absolute;
    width: 300px;
    height: 30px;
    top:60%;
    left: 37%;
}
#KICHTHUOC{
    position: absolute;
    width: 300px;
    height: 30px;
    top:65%;
    left: 37%;
}
#GIA{
    position: absolute;
    width: 300px;
    height: 30px;
    top:70%;
    left: 37%;
}

#DK{
    position: absolute;
    width: 300px;
    height: 30px;
    top:75%;
    left: 37%;
}

  </style>
</head>
<body>

<div class="p-5 bg-primary text-white text-center">
  <h1>TRANG QUẢN TRỊ</h1>
  
</div>

<div class="container-fluid mt-5">

  <div class="row">
    <div class="col-sm-4">
      <h2>Quản lý dữ liệu</h2>
      
      <ul class="nav flex-column">
      <li class="nav-item">
          <a class="nav-link" href="quantri.php">Trang chủ quản trị</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_nguoidung.php">Người dùng</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_chude.php">Chủ đề</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_tacgia.php">Tác giả</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_tacpham.php">Tác phẩm</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">Bình luận</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Đăng xuất</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ql_binhluan.php">   </a>
        </li>
       
       
      

      
        
      </ul>
    </div>

<!--end header-->

    <div class="col-sm-8">
    <form method = "post"> 
            <input id="MA" type = "text" name = "ma" placeholder="Nhập mã">
            <input id="TEN" type = "text" name = "ten" placeholder="Nhập tên">
            <input id="MACHUDE" type = "text" name = "machude" placeholder="Nhập mã chủ đề">
            <input id="MATACGIA" type = "text" name = "matacgia" placeholder="Nhập mã tác giả">
            <input id="HINHANH" type = "text" name = "hinhanh" placeholder="Nhập đường dẫn hình ảnh">
            <input id="MOTA" type = "text" name = "mota" placeholder="Nhập mô tả">
            <input id="NAMSANGTAC" type = "text" name = "namsangtac" placeholder="Nhập năm sáng tác">
            <input id="CHATLIEU" type = "text" name = "chatlieu" placeholder="Nhập chất liệu">
            <input id="KICHTHUOC" type = "text" name = "kichthuoc" placeholder="Nhập kích thước">
            <input id="GIA" type = "text" name = "gia" placeholder="Nhập giá">
            <input id="DK" type = "submit" name = "them" value = "Thêm">
     </form>
      
  </div>

<!--start footer-->
<?php
  include_once("footer.php");
?>

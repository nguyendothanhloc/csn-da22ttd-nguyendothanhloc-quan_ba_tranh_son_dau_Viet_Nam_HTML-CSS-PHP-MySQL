<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
// Kết nối đến cơ sở dữ liệu MySQL
$servername = "localhost";
$username = "root"; // Thay bằng username của bạn
$password = ""; // Thay bằng password của bạn
$dbname = "doan"; // Tên cơ sở dữ liệu của bạn

// Tạo kết nối
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

// Lấy từ khóa tìm kiếm từ form
$query = isset($_GET['query']) ? $_GET['query'] : '';

// Nếu có từ khóa tìm kiếm






if ($query != '') {
    // Truy vấn tìm kiếm với LIKE để tìm kiếm tên
    $sql = "SELECT * FROM artist WHERE tentacgia LIKE ?";
    $stmt = $conn->prepare($sql);

    // Thêm dấu % vào từ khóa để tìm kiếm gần đúng
    $searchTerm = "%" . $query . "%";
    
    // Gắn tham số vào câu truy vấn
    $stmt->bind_param('s', $searchTerm);

    // Thực thi câu truy vấn
    $stmt->execute();

    // Lấy kết quả truy vấn
    $result = $stmt->get_result();

    // Hiển thị kết quả tìm kiếm
    echo "<h1>Kết quả tìm kiếm cho: '$query'</h1>";
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {


           echo "<h2>". htmlspecialchars($row['tentacgia']) . "</h2>";?>
           <img src="anh/<?echo $row['anhtg'];?>";
           
         <?php   
        }
    } else {
        echo "<p>Không có bài viết nào phù hợp với từ khóa '$query'.</p>";
    }



    
    

    // Đóng statement
    $stmt->close();
} else {
    echo "<p>Vui lòng nhập từ khóa tìm kiếm.</p>";
}

// Đóng kết nối
$conn->close();
?>  
</body>
</html>

<?php
$sever = 'localhost';
$user = 'root';
$pass = '';
$database = 'db_tranhsondau';

$conn = new mysqli($sever, $user, $pass, $database);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>TÁC PHẨM</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
  .fakeimg {
    height: 200px;
    background: #aaa;
  }
  .khungtranh{
    margin-left: 0%;
  }
  #anhdd{
    margin-left: 20%;
    font-size: 30px;
  }
  #ten{
    margin-left: 20%;
  }
  #chatlieuhanoithu1{
    font-size: 12px;
  }
  </style>
</head>
<body>

<div class="p-5 bg-primary text-white text-center">
  <h1> QUÃNG BÁ TÁC PHẨM TRANH SƠN DẦU</h1>
  
</div>

<div class="container-fluid mt-5">

  <div class="row">
    <div class="col-sm-4">
      <h2>Quản lý dữ liệu</h2>
      
      <ul class="nav flex-column">
      <form method="GET" action="timkiemtacpham.php">
    <input type="text" name="tukhoa" placeholder="Nhập từ khóa">
    <button type="submit">Tìm kiếm</button>
    </form>

        <li class="nav-item">
          <a class="nav-link" href="tacpham.php">TÁC PHẨM</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="tacgia.php">TÁC GIẢ</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="chude.php">CHỦ ĐỀ</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="tacpham.php">Tác phẩm</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="binhluan.php">Bình luận</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Đăng xuất</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="trangchu.php">Trang Chủ</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <?php

//$sql = "SELECT hinhanh FROM tacpham WHERE ma = 333 ";

//$result = $conn->query($sql);


//if ($result->num_rows > 0) {
 //  while($row = $result->fetch_assoc()) {
   
?>

<!--<img src="../images/<?php echo $row['hinhanh'] ?>" style="width: 200px;" alt=""> -->



<?php
   //}
 //} 
?>


     
      </ul>
    </div>

<!--end header-->

    <div class="col-sm-8">
      <!--QUÃNG BÁ TÁC PHẨM TRANH SƠN DẦU-->

<div class="khungtranh">

<?php
      $sql = "SELECT hinhanh FROM tacpham WHERE ma = 1003 ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
   while($row = $result->fetch_assoc()) {

?>

<img src="../images/<?php echo $row['hinhanh'] ?>" id="anhdd" style="width: 500px; height: 500px;" alt="">
<?php
   }
 } 
?>     
  </div>
<!-- xuất tác phẩm ra-->
  <?php
      $sql = "SELECT * FROM tacpham WHERE ma = 1003 ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
   while($row = $result->fetch_assoc()) {

?>

<h1 id="ten"><?php echo $row['ten'] ?></h1>
<h4 id="chatlieuhanoithu1"><?php echo $row['chatlieu'] ?></h4>
<?php
   }
 } 
?>  



</div>
  </div>








<!--start footer-->
<?php
  include_once("footer.php");
?>
<style>
    #minhchinh{
        margin-left: 20%;
    }
</style>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tìm kiếm tác giả</title>


    
</head>
<style>
body{
    background-color: #880000;
}
#tde{
    position: absolute;
    color: yellow;
    margin-left: 40%;
    margin-top: 1%
}
#tk{
    position: absolute;
    margin-left: 40%;
    margin-top: 5%;   
}
#tim{
    position: absolute;
    margin-left: 52%;
    margin-top: 5%;   
}


.tacgia{
    
    position: absolute;
    width: 300px;
    height: 2000px;
    background-color: #111111;
    top: 30%;
    left: 10%;
    min-width: 80%;
    min-height: 13%;
 
}

#tgia{
  text-align: center;
  align-items: center;
  color: yellow;

}
#giapvantuan{
  width: 250px;
  height: 265px;
  margin-top: 1%;
  margin-left: 1%;
 
}
.anhtgia1{
  position: absolute;
  background-color: rgb(20, 19, 19);
  width: 255px;
  height: 350px;
  margin-top: 10%;
  margin-left: 5%;
  float : left;
}
.anhtgia1:hover {
  background-color:rgb(38, 36, 36) ;
  color: rgb(20, 19, 19);
}

#GiapVanTuan{
  color: white;
  text-align: center;
  font-family: Arial, Helvetica, sans-serif;
  font-size:12px;
}



#minhchinh{
  width: 250px;
  height: 265px;
  margin-top: 1%;
  margin-left: 1%;
}
.anhtgia2{
position: absolute;
background-color: rgb(20, 19, 19);
width: 255px;
height: 350px;
margin-top: 10%;
margin-left: 36%;


}
.anhtgia2:hover {
  background-color:rgb(38, 36, 36) ;
  color: rgb(20, 19, 19);
}
#MinhChinh{
  color: white;
  text-align: center;
  font-family: Arial, Helvetica, sans-serif;
  font-size:12px;
}

#lamducmanh{
  width: 250px;
  height: 265px;
  margin-top: 1%;
  margin-left: 1%;
}
.anhtgia3{
position: absolute;
background-color: rgb(20, 19, 19);
width: 255px;
height: 350px;
margin-top: 10%;
margin-left:67%;

}
.anhtgia3:hover {
  background-color:rgb(38, 36, 36) ;
  color: rgb(20, 19, 19);
}
#LamDucManh{
  color: white;
  text-align: center;
  font-family: Arial, Helvetica, sans-serif;
  font-size:12px;
}

#maihuydung{
  width: 250px;
  height: 265px;
  margin-top: 1%;
  margin-left: 1%;
}
.anhtgia4{
position: absolute;
background-color: rgb(20, 19, 19);
width: 255px;
height: 350px;
margin-top: 45%;
margin-left:5%;

}
.anhtgia4:hover {
  background-color:rgb(38, 36, 36) ;
  color: rgb(20, 19, 19);
}
#MaiHuyDung{
  color: white;
  text-align: center;
  font-family: Arial, Helvetica, sans-serif;
  font-size:12px;
}


#ngoduchoang{
  width: 250px;
  height: 265px;
  margin-top: 1%;
  margin-left: 1%;
}
.anhtgia5{
position: absolute;
background-color: rgb(20, 19, 19);
width: 255px;
height: 350px;
margin-top: 45%;
margin-left: 36%;


}
.anhtgia5:hover {
  background-color:rgb(38, 36, 36) ;
  color: rgb(20, 19, 19);
}
#NgoDucHoang{
  color: white;
  text-align: center;
  font-family: Arial, Helvetica, sans-serif;
  font-size:12px;
}

#nguyenphanbach{
  width: 250px;
  height: 265px;
  margin-top: 1%;
  margin-left: 1%;
}
.anhtgia6{
position: absolute;
background-color: rgb(20, 19, 19);
width: 255px;
height: 350px;
margin-top: 45%;
margin-left:67%;

}
.anhtgia6:hover {
  background-color:rgb(38, 36, 36) ;
  color: rgb(20, 19, 19);
}
#NguyenPhanBach{
  color: white;
  text-align: center;
  font-family: Arial, Helvetica, sans-serif;
  font-size:12px;
}

#khongdoduy{
  width: 250px;
  height: 265px;
  margin-top: 1%;
  margin-left: 1%;
}
.anhtgia7{
position: absolute;
background-color: rgb(20, 19, 19);
width: 255px;
height: 350px;
margin-top: 80%;
margin-left:5%;

}
.anhtgia7:hover {
  background-color:rgb(38, 36, 36) ;
  color: rgb(20, 19, 19);
}
#KhongDoDuy{
  color: white;
  text-align: center;
  font-family: Arial, Helvetica, sans-serif;
  font-size:12px;
}

#luongtrung{
  width: 250px;
  height: 265px;
  margin-top: 1%;
  margin-left: 1%;
}
.anhtgia8{
position: absolute;
background-color: rgb(20, 19, 19);
width: 255px;
height: 350px;
margin-top: 80%;
margin-left: 36%;


}
.anhtgia8:hover {
  background-color:rgb(38, 36, 36) ;
  color: rgb(20, 19, 19);
}
#LuongTrung{
  color: white;
  text-align: center;
  font-family: Arial, Helvetica, sans-serif;
  font-size:12px;
}


#tranvietthuc{
  width: 250px;
  height: 265px;
  margin-top: 1%;
  margin-left: 1%;
}
.anhtgia9{
position: absolute;
background-color: rgb(20, 19, 19);
width: 255px;
height: 350px;
margin-top: 80%;
margin-left:67%;

}
.anhtgia9:hover {
  background-color:rgb(38, 36, 36) ;
  color: rgb(20, 19, 19);
}
#TranVietThuc{
  color: white;
  text-align: center;
  font-family: Arial, Helvetica, sans-serif;
  font-size:12px;
}

#dangvuha{
  width: 250px;
  height: 265px;
  margin-top: 1%;
  margin-left: 1%;
}
.anhtgia10{
position: absolute;
background-color: rgb(20, 19, 19);
width: 255px;
height: 350px;
margin-top: 115%;
margin-left:5%;

}
.anhtgia10:hover {
  background-color:rgb(38, 36, 36) ;
  color: rgb(20, 19, 19);
}
#DangVuHa{
  color: white;
  text-align: center;
  font-family: Arial, Helvetica, sans-serif;
  font-size:12px;
}

#dauquangtoan{
  width: 250px;
  height: 265px;
  margin-top: 1%;
  margin-left: 1%;
}
.anhtgia11{
position: absolute;
background-color: rgb(20, 19, 19);
width: 255px;
height: 350px;
margin-top: 115%;
margin-left: 36%;


}
.anhtgia11:hover {
  background-color:rgb(38, 36, 36) ;
  color: rgb(20, 19, 19);
}
#DauQuangToan{
  color: white;
  text-align: center;
  font-family: Arial, Helvetica, sans-serif;
  font-size:12px;
}
 #trangchu{
    position: absolute;
    color: white;
    margin-top: 11%;
    margin-left: 10%;  
 }
</style>
<body>
    <h1 id="tde">TÌM KIẾM TÁC GIẢ</h1>
    <form action="search.php" method="GET">
        <input id="tk"type="text" name="query" placeholder="Nhập từ khóa tìm kiếm" required>
        <button id="tim"type="submit">Tìm kiếm</button>
        <a id="trangchu" href="trangnguoidung.php" style="text-decoration: none;"> TRANG CHỦ</a>
    </form>

    <div class="tacgia">
        <h1 id="tgia" >TÁC GIẢ</h1>

        <form method="post" action="search.php">

        <div class="anhtgia1">
          <?php
          echo '<img id="giapvantuan" src = "../image/giapvantuan.jpg">';
          
          ?>
           
           <h1 id="GiapVanTuan">GIÁP VĂN TUẤN</h1>
        </div>


        <div class="anhtgia2">
          <?php
          echo '<img id="minhchinh" src = "../image/minhchinh.jpg">';
          
          ?>
          
          <h1 id="MinhChinh">MINH CHÍNH</h1>
           
        </div>


        <div class="anhtgia3">
          <?php
          echo '<img id="lamducmanh" src = "../image/lamducmanh.jpg">';
          
          ?>
           <h1 id="LamDucManh">LÂM ĐỨC MẠNH</h1>
        </div>

        <div class="anhtgia4">
          <?php
          echo '<img id="maihuydung" src = "../image/maihuydung.jpg">';
          
          ?>
           <h1 id="MaiHuyDung">MAI HUY DŨNG</h1>
        </div>
        <div class="anhtgia5">
          <?php
            echo '<img id="ngoduchoang" src = "../image/ngoduchoang.jpg">';
          
          ?>
           <h1 id="NgoDucHoang">NGÔ ĐỨC HOÀNG</h1>
        </div>

        <div class="anhtgia6">
          <?php
            echo '<img id="nguyenphanbach" src = "../image/nguyenphanbach.jpg">';
          
          ?>
           <h1 id="NguyenPhanBach">NGUYỄN PHAN BÁCH</h1>
        </div>
        <div class="anhtgia7">
          <?php
            echo '<img id="khongdoduy" src = "../image/khongdoduy.jpg">';
          
          ?>
           <h1 id="KhongDoDuy">KHỔNG ĐỖ DUY</h1>
        </div>
        <div class="anhtgia8">
          <?php
            echo '<img id="luongtrung" src = "../image/luongtrung.jpg">';
          
          ?>
           <h1 id="LuongTrung">LƯƠNG TRUNG</h1>
        </div>

        <div class="anhtgia9">
          <?php
            echo '<img id="tranvietthuc" src = "../image/tranvietthuc.jpg">';
          
          ?>
           <h1 id="TranVietThuc">TRẦN VIỆT THỨC</h1>
        </div>

        <div class="anhtgia10">
          <?php
            echo '<img id="dangvuha" src = "../image/dangvuha.jpg">';
          
          ?>
           <h1 id="DangVuHa">ĐẶNG VŨ HÀ</h1>
        </div>

        <div class="anhtgia11">
          <?php
            echo '<img id="dauquangtoan" src = "../image/dauquangtoan.jpg">';
          
          ?>
           <h1 id="DauQuangToan">ĐẬU QUANG TOÀN</h1>
        </div>
        </form>
        </div>
       

      
    
    
</html>

<?php
    $sever = 'localhost';
    $user = 'root';
    $pass = '';
    $database = 'doan';
    $conn = new mysqli($sever, $user, $pass, $database);
    session_start();
    if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['them'])){
        $ten = $_POST['ten'];
        $email = $_POST['email'];
        $matkhau = $_POST['matkhau'];
        $diachi = $_POST['diachi'];
    $them = "INSERT INTO nguoidung (ten, email, matkhau, diachi )VALUES(?,?,?,?) ";
        $n = $conn->prepare($them);
        $n->bind_param("ssss", $ten, $email, $matkhau, $diachi);
        $n->execute();
        $n->close();
        header('Location:dangnhap.php');
        exit();

    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng Ký</title>
</head>
<style>
.khungdn{
    position: absolute;
    width: 400px;
    height: 600px;
    background-color: #880000;
    text-align: center;
    align-items: center;
    min-width:80%;
    min-height: 80%;
    margin-left: 150px;
    
}

.tieude{
    position: absolute;
    text-align: center;
    align-items: center;
}
#TEN{
    position: absolute;
    width: 300px;
    height: 30px;
    top:30%;
    left: 37%;
    
}
#avta{
    position: absolute;
    width: 70px;
    height: 70px;
    border-radius:50% ;
    left: 47%;
    
}
#EMAIL{
    position: absolute;
    width: 300px;
    height: 30px;
    top:40%;
    left: 37%;
}
#PW{
    position: absolute;
    width: 300px;
    height: 30px;
    top:50%;
    left: 37%;   
}
#DC{
    position: absolute;
    width: 300px;
    height: 30px;
    top:60%;
    left: 37%;  
}
#DK{
    position: absolute;
    width: 300px;
    height: 30px;
    top:70%;
    left: 37%;
}
</style>
<body>
 
<div class ="khungdn">
     <form method = "post"> 
        <h1 id="tieude"> ĐĂNG KÝ </h1>
        <img id="avta" src="../image/avt.jpg" alt="">

       
            <input id="TEN" type = "text" name = "ten" placeholder="Nhập tên">
            <input id="EMAIL" type = "email" name = "email" placeholder="Nhập email">
            <input id="PW" type = "password" name = "matkhau" placeholder="Nhập mật khẩu">
            <input id="DC" type = "text" name = "diachi" placeholder="Nhập địa chỉ">
            <input id="DK" type = "submit" name = "them" value = "Đăng Ký">
     </form>
</div>


    
</body>
</html>
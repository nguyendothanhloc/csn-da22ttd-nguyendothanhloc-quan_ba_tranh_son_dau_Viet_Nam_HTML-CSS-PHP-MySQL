<?php
 $sever = 'localhost';
 $user = 'root';
 $pass = '';
 $database = 'doan';
 $conn = new mysqli($sever, $user, $pass, $database);
 ?>

 <?php

 $sql = "SELECT anh FROM tacpham";
 $result = $conn->query($sql);


 if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
    

?>

 <img src="../images/<?php echo $row['anh'] ?>" alt="">

 ?>

<?php
    }
  } else {
    echo "0 results";
  }
?>
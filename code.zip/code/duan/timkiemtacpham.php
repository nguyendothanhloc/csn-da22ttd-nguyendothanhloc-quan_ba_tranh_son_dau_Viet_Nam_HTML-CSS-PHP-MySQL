<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_tranhsondau";

// Kết nối cơ sở dữ liệu
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}
?>









<!DOCTYPE html>
<html lang="en">
<head>
  <title>TÁC PHẨM</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
  .fakeimg {
    height: 200px;
    background: #aaa;
  }
  .khungtranh{
    margin-left: 0%;
  }
  #hanoithu1{
    font-size: 30px;
  }
  #anhhanoithu1{
   
  }
  #chatlieuhanoithu1{
    font-size: 12px;
  }
  #motakq{
    font-size: 14px;
  }
  #chatlieukq{
    font-size: 14px;
  }
  #kichthuockq{
    font-size: 14px;
  }
  #giakq{
    font-size: 14px;
  }
  #binhluantp{
    margin-top: 0%;
  }
  </style>
</head>
<body>

<div class="p-5 bg-primary text-white text-center">
  <h1> QUÃNG BÁ TÁC PHẨM TRANH SƠN DẦU</h1>
  
</div>

<div class="container-fluid mt-5">

  <div class="row">
    <div class="col-sm-4">
      <h2>Quản lý dữ liệu</h2>
      
      <ul class="nav flex-column">
      <form method="GET" action="timkiemtacpham.php">
    <input type="text" name="tukhoa" placeholder="Nhập từ khóa">
    <button type="submit">Tìm kiếm</button>
    </form>

        <li class="nav-item">
          <a class="nav-link" href="tacpham.php">TÁC PHẨM</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="tacgia.php">TÁC GIẢ</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="chude.php">CHỦ ĐỀ</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="binhluan.php">Bình luận</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Đăng xuất</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="trangchu.php">Trang Chủ</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">   </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">  </a>
        </li>
        

      </ul>
    </div>

<!--end header-->

    <div class="col-sm-8">


    <?php
// Lấy từ khóa từ form tìm kiếm
$tukhoa = $_GET['tukhoa'] ?? '';

// Câu truy vấn
$sql = "SELECT * FROM tacpham WHERE ten LIKE ?";
$stmt = $conn->prepare($sql);
$search = "%" . $tukhoa . "%";
$stmt->bind_param("s", $search);

// Thực thi câu truy vấn
$stmt->execute();
$result = $stmt->get_result();

// Hiển thị kết quả
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
    ?><img src="../images/<?php echo $row['hinhanh'] ?> "  style="width: 600px; height: 400px;" alt="" alt=""><?php
    ?><h1 id="imgkq"><?php echo "Tên: " . $row['ten'] . "<br>";?></h1><?php
    ?><h1 id="motakq"><?php echo "Mô tả: " . $row['mota'] . "<br>";?></h1><?php
    ?><h1 id="chatlieukq"><?php echo "Chất liệu: " . $row['chatlieu'] . "<br>";?></h1><?php
    ?><h1 id="kichthuockq"><?php echo "Kích thước: " . $row['kichthuoc'] . "<br>";?></h1><?php
    ?><h1 id="giakq"><?php echo "Giá : " . $row['gia'] . "<br>";?></h1><?php
    ?>
    
    
    <form method="POST" action="binhluan.php">  
    <input type="text" name="noidung" id="noidung" required  placeholder="Bình luận">

    <input id="DK" type = "submit" name = "them" value = "gửi">
    </form>
</form><br><br><?php
    
    
    
    }
} else {
    echo "Không tìm thấy kết quả.";
}

// Đóng kết nối
$stmt->close();
$conn->close();
?>
      <!--QUÃNG BÁ TÁC PHẨM TRANH SƠN DẦU-->
</div>
  </div>








<!--start footer-->
<?php
  include_once("footer.php");
?>
<style>
    #minhchinh{
        margin-left: 20%;
    }
</style>
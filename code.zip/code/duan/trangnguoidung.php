<?php
    $sever = 'localhost';
    $user = 'root';
    $pass = '';
    $database = 'doan';
    $conn = new mysqli($sever, $user, $pass, $database);
    session_start();
    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website quãng bá tác phẩm tranh sơn dầu Việt Nam</title>
</head>
<style>
body{}
.tieude{
    position: absolute;
    background-color:black; 
    width: 80px;
    height: 50px;
    left: 0%;
    min-width: 100%;
    min-height: 8%;
}
.khung{
    position: absolute;
    width: 400px;
    height: 2560px;
    background-color: #880000;
    left: 10%;
    min-width: 80%;
    min-height: 10%;
}
.menu{
    position: absolute;
    background-color: white; 
    width: 80px;
    height: 70px;
    top: 9%;
    left: 2%;
    min-width: 96%;
    min-height: 1%;
}

.button {
  border: none;
  color: white;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.button1 {
  position: absolute;
  background-color: white; 
  color: black; 
  top:5%;
  left:5%;
  min-width: 10%;
  min-height: 90%;
 
}

.button1:hover {
  background-color: #FFB6C1;
  color: white;
}


.button2 {
  position: absolute;
  background-color: white; 
  color: black; 
  top:5%;
  left:23%;
  min-width: 10%;
  min-height: 90%;
 
}
.button2:hover {
  background-color: #FFB6C1;
  color: white;
}



.button3 {
  position: absolute;
  background-color: white; 
  color: black; 
  top:5%;
  left:41.5%;
  min-width: 10%;
  min-height: 90%;
 
}
.button3:hover {
  background-color:#FFB6C1;
  color: white;
}


.button4 {
  position: absolute;
  background-color: white; 
  color: black; 
  top:5%;
  left:58.8%;
  min-width: 10%;
  min-height: 90%;
 
}
.button4:hover {
  background-color:#FFB6C1;
  color: white;
}



#button5 {
  position: absolute;
  background-color: white; 
  color: black; 
  top:5%;
  left:78%;
  min-width: 10%;
  min-height: 90%;
  
}
#button5:hover {
  background-color: #FFB6C1;
  color: white;
}



#bachlientri8{
    position: absolute;
    width: 500px;
    height: 650px;
    
}
.tranh{
    
    position: absolute;
    width: 300px;
    height: 700px;
    background-color: black;
    top: 15%;
    left: 10%;
    min-width: 80%;
    min-height: 5%;
 
}

#bachlientri8{
    position: absolute;
    width: 250px;
    height: 350px;
    left: 73%;
    top: 2%;
    
}
#sen{
    position: absolute;
    width: 280px;
    height: 500px;
    background-color: white;
    top: 5%;
    left: 5%;
    min-width: 40%;
    min-height: 50%;
}
#quadeo{
    position: absolute;
    width: 280px;
    height: 200px;
    background-color: white;
    top: 5%;
    left: 54%;
    min-width: 40%;
    min-height: 30%;
}
#ca{
    position: absolute;
    width: 280px;
    height: 200px;
    background-color: white;
    top: 46%;
    left: 54%;
    min-width: 40%;
    min-height: 31%;
}
#Logo{
  position: absolute;
  width: 150px;
  height: 150px;
  margin-left: 5%;
}
#vanban{
  color: white;
  font-size: 17px;
  margin-top: 60%;
  text-align: center;
  font-family:Arial;
  
}
.tacgia{
    
    position: absolute;
    width: 300px;
    height: 1100px;
    background-color: black;
    top: 50%;
    left: 10%;
    min-width: 80%;
    min-height: 13%;
 
}

#tgia{
  text-align: center;
  align-items: center;
  color: yellow;

}
#giapvantuan{
  width: 250px;
  height: 265px;
  margin-top: 1%;
  margin-left: 1%;
 
}
.anhtgia1{
  position: absolute;
  background-color: rgb(20, 19, 19);
  width: 255px;
  height: 350px;
  margin-top: 10%;
  margin-left: 5%;
  float : left;
}
.anhtgia1:hover {
  background-color:rgb(38, 36, 36) ;
  color: rgb(20, 19, 19);
}
#GiapVanTuan{
  color: white;
  text-align: center;
  font-family: Arial, Helvetica, sans-serif;
  font-size:12px;
}



#minhchinh{
  width: 250px;
  height: 265px;
  margin-top: 1%;
  margin-left: 1%;
}
.anhtgia2{
position: absolute;
background-color: rgb(20, 19, 19);
width: 255px;
height: 350px;
margin-top: 10%;
margin-left: 36%;


}
.anhtgia2:hover {
  background-color:rgb(38, 36, 36) ;
  color: rgb(20, 19, 19);
}
#MinhChinh{
  color: white;
  text-align: center;
  font-family: Arial, Helvetica, sans-serif;
  font-size:12px;
}

#lamducmanh{
  width: 250px;
  height: 265px;
  margin-top: 1%;
  margin-left: 1%;
}
.anhtgia3{
position: absolute;
background-color: rgb(20, 19, 19);
width: 255px;
height: 350px;
margin-top: 10%;
margin-left:67%;

}
.anhtgia3:hover {
  background-color:rgb(38, 36, 36) ;
  color: rgb(20, 19, 19);
}
#LamDucManh{
  color: white;
  text-align: center;
  font-family: Arial, Helvetica, sans-serif;
  font-size:12px;
}

#maihuydung{
  width: 250px;
  height: 265px;
  margin-top: 1%;
  margin-left: 1%;
}
.anhtgia4{
position: absolute;
background-color: rgb(20, 19, 19);
width: 255px;
height: 350px;
margin-top: 58%;
margin-left:5%;

}
.anhtgia4:hover {
  background-color:rgb(38, 36, 36) ;
  color: rgb(20, 19, 19);
}
#MaiHuyDung{
  color: white;
  text-align: center;
  font-family: Arial, Helvetica, sans-serif;
  font-size:12px;
}


#ngoduchoang{
  width: 250px;
  height: 265px;
  margin-top: 1%;
  margin-left: 1%;
}
.anhtgia5{
position: absolute;
background-color: rgb(20, 19, 19);
width: 255px;
height: 350px;
margin-top: 58%;
margin-left: 36%;


}
.anhtgia5:hover {
  background-color:rgb(38, 36, 36) ;
  color: rgb(20, 19, 19);
}
#NgoDucHoang{
  color: white;
  text-align: center;
  font-family: Arial, Helvetica, sans-serif;
  font-size:12px;
}

#nguyenphanbach{
  width: 250px;
  height: 265px;
  margin-top: 1%;
  margin-left: 1%;
}
.anhtgia6{
position: absolute;
background-color: rgb(20, 19, 19);
width: 255px;
height: 350px;
margin-top: 58%;
margin-left:67%;

}
.anhtgia6:hover {
  background-color:rgb(38, 36, 36) ;
  color: rgb(20, 19, 19);
}
#NguyenPhanBach{
  color: white;
  text-align: center;
  font-family: Arial, Helvetica, sans-serif;
  font-size:12px;
}
#tc{
  text-decoration: none;
}
.noidungws{
  position: absolute;
  width: 200px;
  height: 300px;
  background-color: #111111;
  top: 100%;
  min-height: 10%;
  min-width: 100%;

}
#tieudewws{
  position: absolute;
  color: white;
  margin-left:18%;
  margin-top: 5%;

}
</style>
<body>

    <form class="khung">
        <div class="tieude">
          <h1 id="tieudewws">WEBSITE QUÃNG BÁ TÁC PHẨM TRANH SƠN DẦU VIỆT NAM</h1>
          <?php
          echo '<img id="Logo" src = "../image/logo.jpg">';
          ?>
        </div>
        <div class="menu">
        <button class="button button1"><a id="tc"href="../duan/trangnguoidung.php">TRANG CHỦ</button>
        <button class="button button2">GIỚI THIỆU</button>
        <button class="button button3">THỂ LOẠI</button>
        <button class="button button4"><a href="text.php"style="text-decoration: none;">TÁC GIẢ</a></button>
        <button id="button5" type="submit" name="dangxuat">ĐĂNG XUẤT</button>
        
        </div>
        <div class="tranh">
    
        <?php
        echo '<img id="sen" src = "../image/ten.jpg.jpg">';
        echo '<img id="quadeo" src = "../image/quadeo.jpg">';
        echo '<img id="ca" src = "../image/ca.jpg">'
        ?>
        <p id="vanban">Website quãng bá tác phẩm tranh sơn dầu trưng bày các tác phẩm tranh với các chủ đề khác nhau, phân loại tranh theo đề tài, có nhiều tác phẩm đa dạng về màu sắc, tranh theo từng chủ đề ví dụ như: tranh phong cảnh, tranh động vật, tranh về hoa,... những bức tranh gắn liền với con người Việt Nam. Ngoài ra còn có rất nhiều tác giả, tranh của họ có những nét vẽ đặc trưng và riêng biệt</p>
        </div>
        <div class="tacgia">
        <h1 id="tgia" >TÁC GIẢ</h1>
        <div class="anhtgia1">
          <?php
          echo '<img id="giapvantuan" src = "../image/giapvantuan.jpg">';
          
          ?>
           <h1 id="GiapVanTuan">GIÁP VĂN TUẤN</h1>
        </div>


        <div class="anhtgia2">
          <?php
          echo '<img id="minhchinh" src = "../image/minhchinh.jpg">';
          
          ?>
           <h1 id="MinhChinh">MINH CHÍNH</h1>
        </div>


        <div class="anhtgia3">
          <?php
          echo '<img id="lamducmanh" src = "../image/lamducmanh.jpg">';
          
          ?>
           <h1 id="LamDucManh">LÂM ĐỨC MẠNH</h1>
        </div>

        <div class="anhtgia4">
          <?php
          echo '<img id="maihuydung" src = "../image/maihuydung.jpg">';
          
          ?>
           <h1 id="MaiHuyDung">MAI HUY DŨNG</h1>
        </div>
        <div class="anhtgia5">
          <?php
            echo '<img id="ngoduchoang" src = "../image/ngoduchoang.jpg">';
          
          ?>
           <h1 id="NgoDucHoang">NGÔ ĐỨC HOÀNG</h1>
        </div>

        <div class="anhtgia6">
          <?php
            echo '<img id="nguyenphanbach" src = "../image/nguyenphanbach.jpg">';
          
          ?>
           <h1 id="NguyenPhanBach">NGUYỄN PHAN BÁCH</h1>
        </div>
        </div>
        <div class="noidungws">

        </div>
        
    </form>
    
</body>
</html>
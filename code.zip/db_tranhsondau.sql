-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th12 28, 2024 lúc 06:09 PM
-- Phiên bản máy phục vụ: 10.4.32-MariaDB
-- Phiên bản PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `db_tranhsondau`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `binhluan`
--

CREATE TABLE `binhluan` (
  `ma` int(11) NOT NULL,
  `ma_nguoidung` int(11) NOT NULL,
  `ma_tacpham` int(11) NOT NULL,
  `noidung` text NOT NULL,
  `diem` float NOT NULL,
  `thoigian` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chude`
--

CREATE TABLE `chude` (
  `ma` int(11) NOT NULL,
  `ten` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `chude`
--

INSERT INTO `chude` (`ma`, `ten`) VALUES
(111, 'tacgia'),
(112, 'phongcanh'),
(113, 'pho');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nguoidung`
--

CREATE TABLE `nguoidung` (
  `ma` int(11) NOT NULL,
  `matkhau` text NOT NULL,
  `ten` varchar(50) NOT NULL,
  `hoten` varchar(50) NOT NULL,
  `diachi` varchar(100) NOT NULL,
  `sodienthoai` varchar(100) NOT NULL,
  `quyen` enum('admin','user') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `nguoidung`
--

INSERT INTO `nguoidung` (`ma`, `matkhau`, `ten`, `hoten`, `diachi`, `sodienthoai`, `quyen`) VALUES
(1, '10', 'loc', 'nguyen', 'quan 11', '0333', 'admin'),
(2, 'dfg', 'h', 'nvh', 'travinh', '037', NULL),
(2121, 'nhb', 'Bảo', 'Nguyễn Hoài Bảo', 'Bến Tre', '834', NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tacgia`
--

CREATE TABLE `tacgia` (
  `ma` int(11) NOT NULL,
  `ten` varchar(30) NOT NULL,
  `quoctich` varchar(30) NOT NULL,
  `tieusu` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `tacgia`
--

INSERT INTO `tacgia` (`ma`, `ten`, `quoctich`, `tieusu`) VALUES
(123, 'Giáp Văn Tuấn', 'Việt Nam', 'Họa sỹ Giáp Văn Tuấn sinh năm 1983 tại Bắc Giang. Anh tốt nghiệp ĐH Mỹ Thuật Việt Nam vào tháng 6 năm 2010. Anh là một họa sỹ được đánh giá rất cao về kỹ thuật hình họa. Những đường nét trên cơ thể người được anh miêu tả kỹ càng, sắc nét.\r\n\r\nNăm 2018, đánh dấu một bước ngoặt trong sự nghiệp của anh bằng một triển lãm tranh với đề tài THU cùng với 4 họa sỹ khác. Triển lãm được đánh giá cao và tên tuổi của Giáp Văn Tuấn dần đến gần với công chúng yêu nghệ thuật hơn.\r\n\r\nAnh lựa chọn sơn dầu để thể hiện các tác phẩm của mình. Nói về sơn dầu, đây là một chất liệu được ưa thích và là sự lựa chọn số 1 với các họa sỹ. Từ thế kỷ 16, kỹ thuật sơn dầu đã đạt đến đỉnh cao và trở thành chất liệu thông dụng nhất, được yêu mến nhất và có khả năng biểu đạt phong phú nhất, lấn át hoàn toàn các chất liệu khác. Khả năng biểu đạt của sơn dầu gần như vô tận, nó có khả năng tạo ra những sắc độ tinh tế nhất, sự chuyển đổi màu sắc tinh vi nhất.'),
(124, 'Minh Chính', 'Việt Nam', 'Họa sĩ Minh Chính tên đầy đủ là Nguyễn Minh Chính. Anh sinh năm 1975 và đã tốt nghiệp Khoa Nội thất Trường Đại học Mỹ thuật Công Nghiệp Hà Nội năm 1997. Hiện anh đang là thành viên của nhóm nghệ thuật ChuArt.\r\n\r\nNguyễn Minh Chính là một nghệ sĩ đam mê với dòng tranh phong cảnh. Tuổi thơ của anh trải qua trong cuộc sống khó khăn của Hà Nội sau chiến tranh và tuổi trẻ của anh được chứng kiến thời kỳ đổi mới mạnh mẽ của đất nước.\r\n\r\nMinh Chính có một người ông là Nguyễn Hữu Tòng. Ông từng là sinh viên trường Cao đẳng Mỹ thuật Đông Dương. Anh coi mình là người thừa kế tinh thần của ông, và coi sứ mệnh của mình là kết nối hiện thực và thi ca trong chủ đề phong cảnh Đông Dương.\r\n\r\nTrong sự nghiệp sáng tác nghệ thuật của mình, họa sĩ Minh Chính luôn theo đuổi trường phái “tả thực” trên chất liệu sơn dầu truyền thống. Chính vì vậy, những bức tranh nghệ thuật với chủ đề phong cảnh hay tĩnh vật của anh luôn mang đến những xúc cảm đặc biệt qua những đường nét, chi tiết được khắc họa một cách trau chuốt và tinh tế cùng với sự phối hợp hoàn hảo của màu sắc và ánh sáng.'),
(125, 'Mai Huy Dũng', 'Việt Nam', 'Họa sĩ Mai Huy Dũng sinh năm 1974 tại Hà Nội. Năm 1999, Anh tốt nghiệp ngành Đồ họa & khoa Tạo dáng Công nghiệp của Trường Đại học Mở Hà Nội. Nhắc đến họa sĩ Mai Huy Dũng, chúng ta phải nhắc đến một lối nghĩ, lối cảm hứng đầy táo bạo. Anh là một kẻ coi chuyển động hình thể là sự phản ánh trung thành của nội tâm. Trong các tranh sơn dầu nghệ thuật của Mai Huy Dũng, cơ thể của con người phản chiếu bởi ánh sáng và tạo ra khôn lường những hiệu quả màu sắc, khi dịu êm với sắc đen, khi cực kỳ giận dữ với gam màu tương phản và khi lại trầm tĩnh với sắc nâu tha thiết đến nao lòng… Những cơ bắp trên thân thể nhân vật lúc cuồn cuộn như giông bão, lúc vỡ vụn từng mảnh, lúc xoắn xuýt vào nhau, và có lúc cả hai bầu vú lẫn khoang bụng thấp thoáng hình khuôn mặt. Một sự “mổ xẻ” kì lạ về tâm trí con người.\r\n\r\n“Với tôi, vẽ là được sống!”'),
(126, 'Khổng Đỗ Duy', 'Việt Nam', 'Họa sĩ Khổng Đỗ Duy sinh ra và lớn lên tại Vĩnh Phúc. Anh là một họa sĩ trẻ tài năng với chất liệu sơn dầu.\r\n\r\n\"Tôi làm việc gần như liên tục. Kể cả đi du lịch, tôi vẫn mang theo đồ nghề để tranh thủ những lúc thích hợp có thể ngồi vẽ. Tất nhiên, để có chất liệu phong phú chuẩn bị cho những bức vẽ thì trước đó, tôi đã phải lặn lội, tìm đến với các di tích tại khắp các địa phương trên cả nước; đến bảo tàng để quan sát, tìm hiểu những đồ vật cổ và ghi chép lại tất cả những câu chuyện về nó. Trong tranh của mình, bao giờ tôi cũng cố gắng lồng vào một câu chuyện về chính hình ảnh đó, để bức tranh trở nên sống động, có hồn trước mắt người xem\" họa sĩ Khổng Đỗ Duy chia sẻ.'),
(127, 'Lâm Đức Mạnh', 'Việt Nam', 'Họa sĩ Lâm Đức Mạnh, sinh năm 1972 tại Hà Nội. Anh đã tốt nghiệp khoa Hội họa tại Trường Đại học Mỹ thuật Việt Nam năm 1999. Tác phẩm của Lâm Đức Mạnh chủ yếu thể hiện trên chất liệu sơn dầu vì với anh đây là một loại chất liệu có sức biểu cảm phong phú rất hợp với cảm xúc mạnh mẽ của người nghệ sĩ.\r\n\r\nPhong cách sáng tác của anh chịu ảnh hưởng lớn từ các họa sĩ của trường phái Ấn Tượng với những họa sĩ nổi tiếng như Monet hay Bùi Xuân Phái. Chủ đề thiên nhiên là nguồn cảm hứng sáng tạo bất tận của anh đặc biệt là những bức tranh phong cảnh về vùng đồng bằng sông Hồng nơi anh đã sinh ra và lớn lên. Đối với họa sĩ Lâm Đức Mạnh, đến với thiên nhiên là cách giải thoát cho đời sống tinh thần.'),
(128, 'Lương Trung', 'Việt Nam', 'Họa sĩ Lương Trung tên đầy đủ là Lương Văn Trung. Anh sinh năm 1981 tại Nam Định. Năm 2006, anh tốt nghiệp Trường Đại học Mỹ thuật Hà Nội. Trong sự nghiệp của mình, các bức tranh nghệ thuật của anh đã tham gia rất nhiều triển lãm nghệ thuật như:\r\n2000: Tham gia Triển lãm nghệ thuật Việt Nam và Châu Á\r\n2002: Tham gia Triển lãm nghệ thuật đương đại Việt Nam – Na Uy và Triển lãm nghệ thuật đương đại Đông Nam Á\r\n2003: Tham gia Triển lãm nghệ thuật tại Seoul, Hàn Quốc và Triển lãm nghệ thuật “Tân Niên” tại Nam Sơn Gallery\r\n2004: Tham gia Triển lãm nghệ thuật tại Singapore\r\n2006: Tham gia Triển lãm nghệ thuật nhóm tại 16 Ngô Quyền Hà Nội\r\n2008: Tham gia Triển lãm tranh sơn dầu Việt Nam\r\n2009: Tham gia Triển lãm “Chân Dung” tại Hà Nội\r\n2011: Tham gia Triển lãm “Chân Dung Hà Nội” tổ chức bởi Hiệp hội Mỹ thuật Hà Nội và Triển làm nghệ thuật trẻ\r\n2012: Tham gia Triển lãm Tự họa tại Hà Nội\r\n2013: Tham gia Triển lãm nghệ thuật “Made in Hà Nội” tại Mai Gallery, Hà Nội và Triển lãm nghệ thuật “1 Area” tại 16 Ngô Quyền, Hà Nội'),
(129, 'Ngô Đức Hoàng', 'Việt Nam', 'Hoạ sĩ Ngô Đức Hoàng sinh năm 1974 tại Hà Nội, Việt Nam. Năm 1999, anh tốt nghiệp Khoa Thiết kế Mỹ thuật tại Trường Đại Học Sân Khấu - Điện Ảnh Hà Nội.\r\n\r\n\"Có thể dễ dàng cảm nhận được tình yêu của Hoàng dành cho nền văn hóa Kinh Bắc, đặc biệt là những nét đẹp vốn có trong truyền thống quan họ cũng như các tập quán dân tộc phổ biến ở miền núi phía Bắc. Trong tranh của Hoàng, không gian dường như tràn ngập những khối màu làm nổi bật những hình tượng đặc trưng – những mảng màu gợi cho ta liên tưởng đến những mảng màu thường được sử dụng trong tranh dân gian Đông Hồ. Những biểu tượng đặc trưng của anh, nổi bật trên khối màu, bộc lộ nhiều hơn một chút ảnh hưởng từ nghệ thuật tạo hình truyền thống Việt Nam, dùng hình để diễn nghĩa.\r\n\r\nCó lúc nét vẽ của Hoàng uyển chuyển, liền mạch rất giống tranh dân gian Đông Hồ, có lúc nét đậm pha trộn các sắc thái khác nhau tạo nên sự phong phú về kết cấu gợi nhớ đến cách tô màu thường thấy trong tranh dân gian Hàng Trống.\r\n\r\nTóm lại, Ngô Đức Hoàng đã thành công trong việc tạo dựng phong cách riêng của mình trong đó yếu tố trang trí được thể hiện hài hòa với yếu tố tạo hình – một sự kết hợp tuyệt đẹp giữa truyền thống và hiện đại khắc họa quan niệm về cái đẹp của ngày nay.\" Theo lời của nhà phê bình nghệ thuật Lê Quốc Bảo.'),
(130, 'Nguyễn Phan Bách', 'Việt Nam', 'Hoạ sĩ Nguyễn Phan Bách sinh năm 1976 tại Hà Nội. Năm 2003, anh tốt nghiệp Đại học Mỹ Thuật Hà Nội. Anh luôn cố gắng diễn tả suy nghĩ bằng cây cọ của mình. \"Khi còn nhỏ, bố tôi thường kể chuyện cho tôi nghe theo một cách rất đặc biệt, đó là vừa kể vừa vẽ các nhân vật lên tường cho tôi dễ hiểu. Tôi thích vẽ từ nhỏ, đến khi ý thức được thì đã lựa chọn hội hoạ là cách biểu đạt tư duy của mình.\" họa sĩ Nguyễn Phan Bách chia sẻ.'),
(131, 'Trần Viết Thục', 'Việt Nam', 'Họa sĩ Trần Viết Thục sinh năm 1989 và tốt nghiệp Trường Đại học Mỹ thuật Huế. Anh theo đuổi trường phái nghệ thuật tả thực với những bức tranh chân dung và động vật được giới họa sĩ đánh giá rất cao.\r\n\r\nHọa sĩ Trần Viết Thục là nghệ sĩ theo đuổi phong cách tả thực. Anh vẽ rất cẩn thận, tỉ mỉ, chăm chút cho từng chi tiết, từng màu sắc trong tác phẩm... Tất cả dưới sự tác động của ánh sáng, thời tiết đều hiện lên chân thực và sống động. Nền tranh được anh làm đơn giản nhất có thể, quét mịn và gần như chuyển sắc độ không nhiều với mục đích hướng người xem chú ý vào nhân vật chính trong mỗi bức tranh.'),
(132, 'Đặng Vũ Hà', 'Việt Nam', 'Họa sĩ Đặng Vũ Hà sinh năm 1980 tại Tuyên Quang, tốt nghiệp trường Đại học Mỹ thuật Việt Nam năm 2010, hiện là Hội viên Hội Mỹ thuật Việt Nam. Sau khi tốt nghiệp trường Đại học Mỹ thuật Việt Nam với thành tích xuất sắc, Đặng Vũ Hà được giữ lại trường làm công tác giảng dạy và hiện là giảng viên trẻ nhất của khoa Hội họa. Sáng tác nghệ thuật của anh là sự theo đuổi hội họa biểu hiện với phong cách mãnh liệt tràn đầy cảm hứng.\r\n\r\n\"Theo đuổi phong cách hội họa biểu hiện ấn tượng. Mỗi tác phẩm của tôi đều mang năng lượng từ cuộc sống. Dòng năng lượng bất tận, đa chiều, giàu cảm xúc... Hạnh phúc, hay khổ đau, tươi sáng hay u tối.... đều biểu hiện trên từng nét cọ....\"'),
(133, 'Đậu Quang Toàn', 'Việt Nam', 'Họa sĩ Đậu Quang Toàn sinh năm 1952 và hiện đang sinh sống và làm việc tại Hà Nội. Gia đình của ông luôn gắn liền với nghệ thuật khi 2 người con trai là Đậu Quang Anh & Đậu Quang Nhật đều là những họa sĩ đầy tài năng.\r\n\r\nHọa sĩ Đậu Quang Toàn chia sẻ nguồn cảm hứng của ông đến từ sự khao khát tìm đến cái đẹp, cái chân - thiện - mĩ do đó đều khai thác từ thiên nhiên từ cuộc sống xưa và nay giữa quá khứ và hiện tại.\r\n\r\nHoạ sĩ lão làng Ngô Thành Nhân nhận định: \"Đậu Quang Toàn là một tay chơi màu trầm ấm, mạch lạc trong bút pháp\"');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tacpham`
--

CREATE TABLE `tacpham` (
  `ma` int(11) NOT NULL,
  `ten` varchar(30) NOT NULL,
  `machude` int(11) NOT NULL,
  `matacgia` int(11) NOT NULL,
  `hinhanh` text NOT NULL,
  `mota` text NOT NULL,
  `namsangtac` int(11) NOT NULL,
  `chatlieu` varchar(50) NOT NULL,
  `kichthuoc` varchar(50) NOT NULL,
  `gia` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `tacpham`
--

INSERT INTO `tacpham` (`ma`, `ten`, `machude`, `matacgia`, `hinhanh`, `mota`, `namsangtac`, `chatlieu`, `kichthuoc`, `gia`) VALUES
(333, 'Giáp Văn Tuấn', 111, 123, '../images/giapvantuan.jpg', 'Họa sỹ Giáp Văn Tuấn sinh năm 1983 tại Bắc Giang. Anh tốt nghiệp ĐH Mỹ Thuật Việt Nam vào tháng 6 năm 2010. Anh là một họa sỹ được đánh giá rất cao về kỹ thuật hình họa. Những đường nét trên cơ thể người được anh miêu tả kỹ càng, sắc nét.\r\n\r\nNăm 2018, đánh dấu một bước ngoặt trong sự nghiệp của anh bằng một triển lãm tranh với đề tài THU cùng với 4 họa sỹ khác. Triển lãm được đánh giá cao và tên tuổi của Giáp Văn Tuấn dần đến gần với công chúng yêu nghệ thuật hơn.\r\n\r\nAnh lựa chọn sơn dầu để thể hiện các tác phẩm của mình. Nói về sơn dầu, đây là một chất liệu được ưa thích và là sự lựa chọn số 1 với các họa sỹ. Từ thế kỷ 16, kỹ thuật sơn dầu đã đạt đến đỉnh cao và trở thành chất liệu thông dụng nhất, được yêu mến nhất và có khả năng biểu đạt phong phú nhất, lấn át hoàn toàn các chất liệu khác. Khả năng biểu đạt của sơn dầu gần như vô tận, nó có khả năng tạo ra những sắc độ tinh tế nhất, sự chuyển đổi màu sắc tinh vi nhất.', 0, '', '', 0),
(334, 'Minh Chính', 111, 124, '../images/minhchinh.jpg\r\n', 'Họa sĩ Minh Chính tên đầy đủ là Nguyễn Minh Chính. Anh sinh năm 1975 và đã tốt nghiệp Khoa Nội thất Trường Đại học Mỹ thuật Công Nghiệp Hà Nội năm 1997. Hiện anh đang là thành viên của nhóm nghệ thuật ChuArt.\r\n\r\nNguyễn Minh Chính là một nghệ sĩ đam mê với dòng tranh phong cảnh. Tuổi thơ của anh trải qua trong cuộc sống khó khăn của Hà Nội sau chiến tranh và tuổi trẻ của anh được chứng kiến thời kỳ đổi mới mạnh mẽ của đất nước.\r\n\r\nMinh Chính có một người ông là Nguyễn Hữu Tòng. Ông từng là sinh viên trường Cao đẳng Mỹ thuật Đông Dương. Anh coi mình là người thừa kế tinh thần của ông, và coi sứ mệnh của mình là kết nối hiện thực và thi ca trong chủ đề phong cảnh Đông Dương.\r\n\r\nTrong sự nghiệp sáng tác nghệ thuật của mình, họa sĩ Minh Chính luôn theo đuổi trường phái “tả thực” trên chất liệu sơn dầu truyền thống. Chính vì vậy, những bức tranh nghệ thuật với chủ đề phong cảnh hay tĩnh vật của anh luôn mang đến những xúc cảm đặc biệt qua những đường nét, chi tiết được khắc họa một cách trau chuốt và tinh tế cùng với sự phối hợp hoàn hảo của màu sắc và ánh sáng.', 0, '', '', 0),
(335, 'Mai Huy Dũng', 111, 125, '../images/maihuydung.jpg', 'Họa sĩ Mai Huy Dũng sinh năm 1974 tại Hà Nội. Năm 1999, Anh tốt nghiệp ngành Đồ họa & khoa Tạo dáng Công nghiệp của Trường Đại học Mở Hà Nội. Nhắc đến họa sĩ Mai Huy Dũng, chúng ta phải nhắc đến một lối nghĩ, lối cảm hứng đầy táo bạo. Anh là một kẻ coi chuyển động hình thể là sự phản ánh trung thành của nội tâm. Trong các tranh sơn dầu nghệ thuật của Mai Huy Dũng, cơ thể của con người phản chiếu bởi ánh sáng và tạo ra khôn lường những hiệu quả màu sắc, khi dịu êm với sắc đen, khi cực kỳ giận dữ với gam màu tương phản và khi lại trầm tĩnh với sắc nâu tha thiết đến nao lòng… Những cơ bắp trên thân thể nhân vật lúc cuồn cuộn như giông bão, lúc vỡ vụn từng mảnh, lúc xoắn xuýt vào nhau, và có lúc cả hai bầu vú lẫn khoang bụng thấp thoáng hình khuôn mặt. Một sự “mổ xẻ” kì lạ về tâm trí con người.\r\n\r\n“Với tôi, vẽ là được sống!”', 0, '', '', 0),
(336, 'Khổng Đỗ Duy', 111, 126, '../images/khongdoduy.jpg', 'Họa sĩ Khổng Đỗ Duy sinh ra và lớn lên tại Vĩnh Phúc. Anh là một họa sĩ trẻ tài năng với chất liệu sơn dầu.\r\n\r\n\"Tôi làm việc gần như liên tục. Kể cả đi du lịch, tôi vẫn mang theo đồ nghề để tranh thủ những lúc thích hợp có thể ngồi vẽ. Tất nhiên, để có chất liệu phong phú chuẩn bị cho những bức vẽ thì trước đó, tôi đã phải lặn lội, tìm đến với các di tích tại khắp các địa phương trên cả nước; đến bảo tàng để quan sát, tìm hiểu những đồ vật cổ và ghi chép lại tất cả những câu chuyện về nó. Trong tranh của mình, bao giờ tôi cũng cố gắng lồng vào một câu chuyện về chính hình ảnh đó, để bức tranh trở nên sống động, có hồn trước mắt người xem\" họa sĩ Khổng Đỗ Duy chia sẻ.', 0, '', '', 0),
(337, 'Lâm Đức Mạnh', 111, 127, '../images/lamducmanh.jpg', 'Họa sĩ Lâm Đức Mạnh, sinh năm 1972 tại Hà Nội. Anh đã tốt nghiệp khoa Hội họa tại Trường Đại học Mỹ thuật Việt Nam năm 1999. Tác phẩm của Lâm Đức Mạnh chủ yếu thể hiện trên chất liệu sơn dầu vì với anh đây là một loại chất liệu có sức biểu cảm phong phú rất hợp với cảm xúc mạnh mẽ của người nghệ sĩ.\r\n\r\nPhong cách sáng tác của anh chịu ảnh hưởng lớn từ các họa sĩ của trường phái Ấn Tượng với những họa sĩ nổi tiếng như Monet hay Bùi Xuân Phái. Chủ đề thiên nhiên là nguồn cảm hứng sáng tạo bất tận của anh đặc biệt là những bức tranh phong cảnh về vùng đồng bằng sông Hồng nơi anh đã sinh ra và lớn lên. Đối với họa sĩ Lâm Đức Mạnh, đến với thiên nhiên là cách giải thoát cho đời sống tinh thần.', 0, '', '', 0),
(338, 'Lương Trung', 111, 128, '../images/luongtrung.jqg', 'Họa sĩ Lương Trung tên đầy đủ là Lương Văn Trung. Anh sinh năm 1981 tại Nam Định. Năm 2006, anh tốt nghiệp Trường Đại học Mỹ thuật Hà Nội. Trong sự nghiệp của mình, các bức tranh nghệ thuật của anh đã tham gia rất nhiều triển lãm nghệ thuật như:\r\n2000: Tham gia Triển lãm nghệ thuật Việt Nam và Châu Á\r\n2002: Tham gia Triển lãm nghệ thuật đương đại Việt Nam – Na Uy và Triển lãm nghệ thuật đương đại Đông Nam Á\r\n2003: Tham gia Triển lãm nghệ thuật tại Seoul, Hàn Quốc và Triển lãm nghệ thuật “Tân Niên” tại Nam Sơn Gallery\r\n2004: Tham gia Triển lãm nghệ thuật tại Singapore\r\n2006: Tham gia Triển lãm nghệ thuật nhóm tại 16 Ngô Quyền Hà Nội\r\n2008: Tham gia Triển lãm tranh sơn dầu Việt Nam\r\n2009: Tham gia Triển lãm “Chân Dung” tại Hà Nội\r\n2011: Tham gia Triển lãm “Chân Dung Hà Nội” tổ chức bởi Hiệp hội Mỹ thuật Hà Nội và Triển làm nghệ thuật trẻ\r\n2012: Tham gia Triển lãm Tự họa tại Hà Nội\r\n2013: Tham gia Triển lãm nghệ thuật “Made in Hà Nội” tại Mai Gallery, Hà Nội và Triển lãm nghệ thuật “1 Area” tại 16 Ngô Quyền, Hà Nội', 0, '', '', 0),
(339, 'Ngô Đức Hoàng', 111, 129, '../images/ngoduchoang.jpg', 'Hoạ sĩ Ngô Đức Hoàng sinh năm 1974 tại Hà Nội, Việt Nam. Năm 1999, anh tốt nghiệp Khoa Thiết kế Mỹ thuật tại Trường Đại Học Sân Khấu - Điện Ảnh Hà Nội.\r\n\r\n\"Có thể dễ dàng cảm nhận được tình yêu của Hoàng dành cho nền văn hóa Kinh Bắc, đặc biệt là những nét đẹp vốn có trong truyền thống quan họ cũng như các tập quán dân tộc phổ biến ở miền núi phía Bắc. Trong tranh của Hoàng, không gian dường như tràn ngập những khối màu làm nổi bật những hình tượng đặc trưng – những mảng màu gợi cho ta liên tưởng đến những mảng màu thường được sử dụng trong tranh dân gian Đông Hồ. Những biểu tượng đặc trưng của anh, nổi bật trên khối màu, bộc lộ nhiều hơn một chút ảnh hưởng từ nghệ thuật tạo hình truyền thống Việt Nam, dùng hình để diễn nghĩa.\r\n\r\nCó lúc nét vẽ của Hoàng uyển chuyển, liền mạch rất giống tranh dân gian Đông Hồ, có lúc nét đậm pha trộn các sắc thái khác nhau tạo nên sự phong phú về kết cấu gợi nhớ đến cách tô màu thường thấy trong tranh dân gian Hàng Trống.\r\n\r\nTóm lại, Ngô Đức Hoàng đã thành công trong việc tạo dựng phong cách riêng của mình trong đó yếu tố trang trí được thể hiện hài hòa với yếu tố tạo hình – một sự kết hợp tuyệt đẹp giữa truyền thống và hiện đại khắc họa quan niệm về cái đẹp của ngày nay.\" Theo lời của nhà phê bình nghệ thuật Lê Quốc Bảo.', 0, '', '', 0),
(340, 'Nguyễn Phan Bách', 111, 130, '../images/nguyenphanbach.jpg', 'Hoạ sĩ Nguyễn Phan Bách sinh năm 1976 tại Hà Nội. Năm 2003, anh tốt nghiệp Đại học Mỹ Thuật Hà Nội. Anh luôn cố gắng diễn tả suy nghĩ bằng cây cọ của mình. \"Khi còn nhỏ, bố tôi thường kể chuyện cho tôi nghe theo một cách rất đặc biệt, đó là vừa kể vừa vẽ các nhân vật lên tường cho tôi dễ hiểu. Tôi thích vẽ từ nhỏ, đến khi ý thức được thì đã lựa chọn hội hoạ là cách biểu đạt tư duy của mình.\" họa sĩ Nguyễn Phan Bách chia sẻ.', 0, '', '', 0),
(341, 'Trần Viết Thục', 111, 131, '../images/tranvietthuc.jpg', 'Họa sĩ Trần Viết Thục sinh năm 1989 và tốt nghiệp Trường Đại học Mỹ thuật Huế. Anh theo đuổi trường phái nghệ thuật tả thực với những bức tranh chân dung và động vật được giới họa sĩ đánh giá rất cao.\r\n\r\nHọa sĩ Trần Viết Thục là nghệ sĩ theo đuổi phong cách tả thực. Anh vẽ rất cẩn thận, tỉ mỉ, chăm chút cho từng chi tiết, từng màu sắc trong tác phẩm... Tất cả dưới sự tác động của ánh sáng, thời tiết đều hiện lên chân thực và sống động. Nền tranh được anh làm đơn giản nhất có thể, quét mịn và gần như chuyển sắc độ không nhiều với mục đích hướng người xem chú ý vào nhân vật chính trong mỗi bức tranh.', 0, '', '', 0),
(342, 'Đặng Vũ Hà', 111, 132, '../images/dangvuha.jpg', 'Họa sĩ Đặng Vũ Hà sinh năm 1980 tại Tuyên Quang, tốt nghiệp trường Đại học Mỹ thuật Việt Nam năm 2010, hiện là Hội viên Hội Mỹ thuật Việt Nam. Sau khi tốt nghiệp trường Đại học Mỹ thuật Việt Nam với thành tích xuất sắc, Đặng Vũ Hà được giữ lại trường làm công tác giảng dạy và hiện là giảng viên trẻ nhất của khoa Hội họa. Sáng tác nghệ thuật của anh là sự theo đuổi hội họa biểu hiện với phong cách mãnh liệt tràn đầy cảm hứng.\r\n\r\n\"Theo đuổi phong cách hội họa biểu hiện ấn tượng. Mỗi tác phẩm của tôi đều mang năng lượng từ cuộc sống. Dòng năng lượng bất tận, đa chiều, giàu cảm xúc... Hạnh phúc, hay khổ đau, tươi sáng hay u tối.... đều biểu hiện trên từng nét cọ....\"', 0, '', '', 0),
(343, 'Đậu Quang Toàn', 111, 133, '../images/dauquangtoan.jpg', 'Họa sĩ Đậu Quang Toàn sinh năm 1952 và hiện đang sinh sống và làm việc tại Hà Nội. Gia đình của ông luôn gắn liền với nghệ thuật khi 2 người con trai là Đậu Quang Anh & Đậu Quang Nhật đều là những họa sĩ đầy tài năng.\r\n\r\nHọa sĩ Đậu Quang Toàn chia sẻ nguồn cảm hứng của ông đến từ sự khao khát tìm đến cái đẹp, cái chân - thiện - mĩ do đó đều khai thác từ thiên nhiên từ cuộc sống xưa và nay giữa quá khứ và hiện tại.\r\n\r\nHoạ sĩ lão làng Ngô Thành Nhân nhận định: \"Đậu Quang Toàn là một tay chơi màu trầm ấm, mạch lạc trong bút pháp\"', 0, '', '', 0),
(1000, 'Hà Nội Thu 1', 113, 123, '../images/hanoithu1.jpg', 'Hà Nội Thu 1 - tác giả: Giáp Văn Tuấn', 0, 'Chất liệu: tranh sơn dầu trên toan', 'Kích thước: 130cm x 100cm', 0),
(1001, 'Hà Nội Thu 2', 113, 123, '../images/hanoithu2.jpg', 'Mô tả: Hà Nội Thu 2 - tác giả: Giáp Văn Tuấn ', 0, 'Chất liệu: tranh sơn dầu trên toan', 'Kích thước: 130cm x 100cm', 0),
(1002, 'Hà Nội Thu 3', 113, 123, '../images/hanoithu3.jpg', 'Mô tả: Hà Nội thu 3 - tác giả: Giáp Văn Tuấn', 0, 'tranh sơn dầu trên toan', '100cm x 130cm', 0),
(1003, 'Hide on Bush', 112, 131, '../images/HideonBush.jpg', '', 0, '', '', 0);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `binhluan`
--
ALTER TABLE `binhluan`
  ADD PRIMARY KEY (`ma`),
  ADD KEY `ma_nguoidung` (`ma_nguoidung`),
  ADD KEY `ma_tacpham` (`ma_tacpham`);

--
-- Chỉ mục cho bảng `chude`
--
ALTER TABLE `chude`
  ADD PRIMARY KEY (`ma`);

--
-- Chỉ mục cho bảng `nguoidung`
--
ALTER TABLE `nguoidung`
  ADD PRIMARY KEY (`ma`);

--
-- Chỉ mục cho bảng `tacgia`
--
ALTER TABLE `tacgia`
  ADD PRIMARY KEY (`ma`);

--
-- Chỉ mục cho bảng `tacpham`
--
ALTER TABLE `tacpham`
  ADD PRIMARY KEY (`ma`),
  ADD KEY `machude` (`machude`),
  ADD KEY `matacgia` (`matacgia`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `chude`
--
ALTER TABLE `chude`
  MODIFY `ma` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=114;

--
-- AUTO_INCREMENT cho bảng `tacgia`
--
ALTER TABLE `tacgia`
  MODIFY `ma` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=445;

--
-- AUTO_INCREMENT cho bảng `tacpham`
--
ALTER TABLE `tacpham`
  MODIFY `ma` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1112;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `binhluan`
--
ALTER TABLE `binhluan`
  ADD CONSTRAINT `binhluan_ibfk_1` FOREIGN KEY (`ma_nguoidung`) REFERENCES `nguoidung` (`ma`),
  ADD CONSTRAINT `binhluan_ibfk_2` FOREIGN KEY (`ma_tacpham`) REFERENCES `tacpham` (`ma`);

--
-- Các ràng buộc cho bảng `tacpham`
--
ALTER TABLE `tacpham`
  ADD CONSTRAINT `tacpham_ibfk_1` FOREIGN KEY (`machude`) REFERENCES `chude` (`ma`),
  ADD CONSTRAINT `tacpham_ibfk_2` FOREIGN KEY (`matacgia`) REFERENCES `tacgia` (`ma`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
